package Pedro.Indusphere.repository;

import Pedro.Indusphere.entity.RFID;
import org.springframework.data.jpa.repository.JpaRepository;



public interface RFIDRepository extends JpaRepository<RFID, Long> {
}
