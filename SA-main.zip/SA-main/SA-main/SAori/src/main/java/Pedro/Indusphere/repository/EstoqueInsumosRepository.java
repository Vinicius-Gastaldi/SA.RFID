package Pedro.Indusphere.repository;

import Pedro.Indusphere.entity.EstoqueInsumos;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EstoqueInsumosRepository extends JpaRepository<EstoqueInsumos,Long> {

    Optional<EstoqueInsumos> findByName(String name);

}
