package Pedro.Indusphere.service;

public enum Tamanho {
    PP,
    P,
    M,
    G,
    GG;
}
