package Pedro.Indusphere.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PedidoDTO {

    private Long id;
    private RFIDDTO id_rfid;
    private Date dataPedida;
    private Date dataEntrega;
    private String descricao;

    private PedidoDTO(RFIDDTO id_rfid, Date dataPedida, Date dataEntrega, String descricao) {
        this.id_rfid = id_rfid;
        this.dataPedida = dataPedida;
        this.dataEntrega = dataEntrega;
        this.descricao = descricao;
    }
}
