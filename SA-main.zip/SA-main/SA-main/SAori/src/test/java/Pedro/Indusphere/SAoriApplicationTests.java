package Pedro.Indusphere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SAoriApplicationTests {

	@Test
	void contextLoads() {
	}

}
